# ca.apm.fieldpacks.fuse (1.0.0)

## Description
A monitoring fieldpack for JBoss Fuse. Key focus areas are the Apache Camel framework, Web Service coverage and JMS implementations.

# Installation Instructions

## Prerequisites
APM Java Agent 9.1+ should be installed.

## Dependencies
APM JavaAgent 9.1+

## Installation
Fuse Fieldpack installation
* Unzip the JbossFuseInstrumentation.zip
* Go to your current Introscope Agent installation.
* Copy the file “ca.apm.fieldpacks.agent.fuse.jar” to the Agents “ext” directory.
* Copy the pbd and pbl files to the Agent directory.
* Add the jboss-fuse.pbl files to the directives in the IntroscopeAgent.profile.

## Configuration
see README.md

## Debugging and Troubleshooting
How to debug and troubleshoot the field pack.
